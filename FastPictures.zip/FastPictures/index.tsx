/*
 * FastPictures — an Equicord / Vencord userplugin
 *
 * "Favorite GIFs, but for your own photos." Save images into quick-access folders
 * (with colors) and drop them into any chat in one click.
 *
 * Add pictures:
 *   • the ＋ tile in the gallery (file picker)
 *   • drag-and-drop onto the gallery
 *   • paste (Ctrl+V) while the gallery is open
 *   • right-click any image already in Discord → "Add to Fast Pictures"
 *
 * Send:
 *   • click a picture → attached to the current chat as a normal upload
 *   • 🔗 button → "send as link": the image is uploaded ONCE to your configured
 *     relay path (a channel/DM you pick via right-click → "Use for Fast Pictures
 *     links"), the CDN link is cached on the picture, and from then on sending
 *     as link is instant.
 */

import { addChatBarButton, ChatBarButton, removeChatBarButton } from "@api/ChatButtons";
import { NavContextMenuPatchCallback } from "@api/ContextMenu";
import * as DataStore from "@api/DataStore";
import { definePluginSettings } from "@api/Settings";
import { Devs } from "@utils/constants";
import { sendMessage } from "@utils/discord";
import { Logger } from "@utils/Logger";
import { ModalContent, ModalFooter, ModalHeader, ModalRoot, ModalSize, openModal } from "@utils/modal";
import definePlugin, { OptionType } from "@utils/types";
import { find, findByProps, findByPropsLazy } from "@webpack";
import {
    Button, ChannelStore, Forms, Menu, React, RestAPI,
    SelectedChannelStore, Toasts,
} from "@webpack/common";

// ---- Discord internals -------------------------------------------------------
// All module lookups are done at call time (not import time) and each caller has
// a fallback, so a renamed Discord module degrades gracefully instead of throwing
// "Reflect.get called on non-object".

// ---- Storage -----------------------------------------------------------------

interface Folder { name: string; color: string; }
interface Pic {
    id: string;
    name: string;
    data: string;   // data: URL
    folder: string;
    addedAt: number;
    link?: string;  // cached CDN url after first "send as link"
}
interface Data {
    pics: Pic[];
    folders: Folder[];
}

const KEY = "FastPictures:data";
const DEFAULT_COLOR = "#5865f2";
const logger = new Logger("FastPictures");

let data: Data = { pics: [], folders: [{ name: "General", color: DEFAULT_COLOR }] };

const listeners = new Set<() => void>();
const emit = () => listeners.forEach(l => l());

async function loadData() {
    const raw = (await DataStore.get<any>(KEY)) ?? {};
    const pics: Pic[] = raw.pics ?? [];
    let folders: Folder[] = raw.folders ?? [];
    // migrate v1 (folders were plain strings)
    if (folders.length && typeof folders[0] === "string")
        folders = (folders as unknown as string[]).map(name => ({ name, color: DEFAULT_COLOR }));
    if (!folders.length) folders = [{ name: "General", color: DEFAULT_COLOR }];
    data = { pics, folders };
}
async function persist() {
    await DataStore.set(KEY, data);
    emit();
}

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
const toast = (message: string, type: number) =>
    Toasts.show({ message, type, id: Toasts.genId() });

// ---- Settings ----------------------------------------------------------------

const settings = definePluginSettings({
    relayChannel: {
        type: OptionType.STRING,
        description:
            "Link path: channel/DM id where images get uploaded once to create a shareable link. " +
            "Easiest way to set it: right-click a channel → “Use for Fast Pictures links”.",
        default: "",
    },
});

// ---- Image helpers -----------------------------------------------------------

function fileToDataUrl(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result as string);
        r.onerror = reject;
        r.readAsDataURL(blob);
    });
}

async function addPicFromBlob(blob: Blob, name: string, folder: string) {
    const dataUrl = await fileToDataUrl(blob);
    data.pics.push({ id: uid(), name: name || "image", data: dataUrl, folder, addedAt: Date.now() });
    await persist();
}

async function addPicFromUrl(url: string, name: string, folder: string) {
    try {
        const resp = await fetch(url);
        const blob = await resp.blob();
        await addPicFromBlob(blob, name, folder);
        toast("Added to Fast Pictures", Toasts.Type.SUCCESS);
    } catch (e) {
        logger.error("addPicFromUrl", e);
        toast("Couldn't fetch that image", Toasts.Type.FAILURE);
    }
}

function dataUrlToFile(dataUrl: string, name: string): File {
    const [meta, b64] = dataUrl.split(",");
    const mime = /:(.*?);/.exec(meta)?.[1] || "image/png";
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    const ext = mime.split("/")[1] || "png";
    const filename = /\.[a-z0-9]+$/i.test(name) ? name : `${name}.${ext}`;
    return new File([arr], filename, { type: mime });
}

// ---- Send as upload ------------------------------------------------------------

/** Feeds a file to Discord's chat box as if the user pasted it (no internals needed). */
function pasteFileIntoChat(file: File): boolean {
    const editor = document.querySelector<HTMLElement>(
        '[data-slate-editor="true"], [class*="slateTextArea"], [class*="textArea"] [contenteditable="true"]',
    );
    if (!editor) return false;
    editor.focus();
    const dt = new DataTransfer();
    dt.items.add(file);
    const ev = new ClipboardEvent("paste", { bubbles: true, cancelable: true });
    Object.defineProperty(ev, "clipboardData", { value: dt });
    editor.dispatchEvent(ev);
    return true;
}

function sendPic(pic: Pic, targetChannelId?: string) {
    const channelId = targetChannelId ?? SelectedChannelStore.getChannelId();
    const channel = channelId ? ChannelStore.getChannel(channelId) : null;
    if (!channel) return toast("Open a channel first", Toasts.Type.FAILURE);

    const file = dataUrlToFile(pic.data, pic.name);

    // 1) preferred: Discord's own composer-attach function, resolved at call time
    try {
        const m = findByProps("promptToUpload");
        if (typeof m?.promptToUpload === "function") {
            m.promptToUpload([file], channel, 0);
            return;
        }
    } catch (e) {
        logger.warn("promptToUpload lookup failed, trying fallback", e);
    }

    // 2) fallback: synthesize a paste of the file into the chat box
    if (pasteFileIntoChat(file)) return;

    toast("Couldn't attach: no upload path worked on this Discord build", Toasts.Type.FAILURE);
}

// ---- Send as link ---------------------------------------------------------------

/** Uploads the pic to the relay channel and resolves with the CDN url. */
function uploadToRelay(pic: Pic): Promise<string> {
    return new Promise((resolve, reject) => {
        const relayId = settings.store.relayChannel?.trim();
        if (!relayId)
            return reject(new Error("No link path set. Right-click a channel → “Use for Fast Pictures links”."));
        if (!ChannelStore.getChannel(relayId))
            return reject(new Error("The saved link path channel no longer exists."));

        let CloudUploadCls: any;
        try {
            CloudUploadCls = find(m => m.prototype?.uploadFileToCloud);
        } catch { /* handled below */ }
        if (!CloudUploadCls)
            return reject(new Error("Upload module not found on this Discord build."));

        const file = dataUrlToFile(pic.data, pic.name);
        const upload = new CloudUploadCls(
            { file, isClip: false, isThumbnail: false, platform: 1 },
            relayId, false, 0,
        );
        upload.on("complete", async () => {
            try {
                const res = await RestAPI.post({
                    url: `/channels/${relayId}/messages`,
                    body: {
                        channel_id: relayId,
                        content: "",
                        type: 0,
                        sticker_ids: [],
                        attachments: [{
                            id: "0",
                            filename: upload.filename,
                            uploaded_filename: upload.uploadedFilename,
                        }],
                    },
                });
                const url: string | undefined = res?.body?.attachments?.[0]?.url;
                if (url) resolve(url);
                else reject(new Error("Upload succeeded but no link came back."));
            } catch (e) {
                reject(e);
            }
        });
        upload.on("error", (e: any) => reject(e ?? new Error("Upload failed")));
        upload.upload();
    });
}

async function sendAsLink(pic: Pic, targetChannelId?: string) {
    const channelId = targetChannelId ?? SelectedChannelStore.getChannelId();
    if (!channelId) return toast("Open a channel first", Toasts.Type.FAILURE);
    try {
        let link = pic.link;
        if (!link) {
            toast("Creating link (one-time upload)…", Toasts.Type.MESSAGE);
            link = await uploadToRelay(pic);
            pic.link = link; // cache forever — next time is instant
            await persist();
        }
        await sendMessage(channelId, { content: link });
        toast("Sent as link", Toasts.Type.SUCCESS);
    } catch (e: any) {
        logger.error("sendAsLink", e);
        toast(e?.message ?? `Couldn't send as link: ${e}`, Toasts.Type.FAILURE);
    }
}

// ---- UI ----------------------------------------------------------------------

function useData(): Data {
    const [, force] = React.useReducer((x: number) => x + 1, 0);
    React.useEffect(() => {
        listeners.add(force);
        return () => void listeners.delete(force);
    }, []);
    return data;
}

const inputStyle: React.CSSProperties = {
    flex: 1, padding: "4px 8px", borderRadius: 6, color: "var(--text-normal)",
    border: "1px solid var(--background-modifier-accent)", background: "var(--input-background)",
};
const btnStyle: React.CSSProperties = {
    padding: "4px 10px", borderRadius: 6, border: "none", cursor: "pointer",
    background: "var(--brand-500, #5865f2)", color: "#fff",
};
const addTileStyle: React.CSSProperties = {
    display: "flex", alignItems: "center", justifyContent: "center", height: 96, borderRadius: 6,
    cursor: "pointer", fontSize: 32, userSelect: "none",
    background: "var(--background-secondary-alt)", color: "var(--text-muted)",
};
const overlayBtn: React.CSSProperties = {
    width: 22, height: 22, borderRadius: "50%", border: "none", cursor: "pointer",
    background: "rgba(0,0,0,0.65)", color: "#fff", padding: 0, fontSize: 12, lineHeight: "22px",
};

function Gallery({ modalProps, targetChannelId }: { modalProps: any; targetChannelId?: string; }) {
    const d = useData();
    const [folder, setFolder] = React.useState(d.folders[0]?.name ?? "General");
    const [newFolder, setNewFolder] = React.useState("");
    const [newColor, setNewColor] = React.useState(DEFAULT_COLOR);
    const fileInput = React.useRef<HTMLInputElement>(null);

    const activeFolder = d.folders.find(f => f.name === folder) ?? d.folders[0];
    const pics = d.pics.filter(p => p.folder === activeFolder?.name);

    const onFiles = React.useCallback(async (files: FileList | File[]) => {
        let added = 0;
        for (const f of Array.from(files))
            if (f.type.startsWith("image/")) { await addPicFromBlob(f, f.name, activeFolder.name); added++; }
        if (added) toast(`Added ${added} picture${added > 1 ? "s" : ""}`, Toasts.Type.SUCCESS);
    }, [activeFolder?.name]);

    // Global paste listener while the gallery is open — the modal div itself
    // rarely has focus, so a local onPaste never fired.
    React.useEffect(() => {
        const h = (e: ClipboardEvent) => {
            const files = e.clipboardData?.files;
            if (files?.length) { e.preventDefault(); onFiles(files); }
        };
        document.addEventListener("paste", h);
        return () => document.removeEventListener("paste", h);
    }, [onFiles]);

    return (
        <ModalRoot {...modalProps} size={ModalSize.LARGE}>
            <ModalHeader>
                <Forms.FormTitle style={{ margin: 0 }}>Fast Pictures</Forms.FormTitle>
            </ModalHeader>
            <ModalContent>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", margin: "8px 0 12px" }}>
                    {d.folders.map(f => {
                        const active = f.name === activeFolder?.name;
                        return (
                            <button
                                key={f.name}
                                onClick={() => setFolder(f.name)}
                                style={{
                                    padding: "4px 10px", borderRadius: 6, cursor: "pointer", fontSize: 13,
                                    border: `2px solid ${f.color}`,
                                    background: active ? f.color : "transparent",
                                    color: active ? "#fff" : "var(--text-normal)",
                                    display: "flex", alignItems: "center", gap: 6,
                                }}
                            >
                                <span style={{
                                    width: 8, height: 8, borderRadius: "50%",
                                    background: active ? "#fff" : f.color,
                                }} />
                                {f.name}
                            </button>
                        );
                    })}
                </div>

                <div style={{ display: "flex", gap: 6, marginBottom: 12, alignItems: "center" }}>
                    <input
                        value={newFolder}
                        placeholder="New folder name"
                        style={inputStyle}
                        onChange={e => setNewFolder(e.currentTarget.value)}
                    />
                    <input
                        type="color"
                        value={newColor}
                        title="Folder color"
                        style={{ width: 36, height: 28, padding: 0, border: "none", background: "none", cursor: "pointer" }}
                        onChange={e => setNewColor(e.currentTarget.value)}
                    />
                    <button style={btnStyle} onClick={async () => {
                        const name = newFolder.trim();
                        if (name && !d.folders.some(f => f.name === name)) {
                            data.folders.push({ name, color: newColor });
                            setNewFolder("");
                            await persist();
                            setFolder(name);
                        }
                    }}>Add folder</button>
                    {activeFolder && (
                        <input
                            type="color"
                            value={activeFolder.color}
                            title={`Change color of “${activeFolder.name}”`}
                            style={{ width: 36, height: 28, padding: 0, border: "none", background: "none", cursor: "pointer" }}
                            onChange={async e => {
                                activeFolder.color = e.currentTarget.value;
                                await persist();
                            }}
                        />
                    )}
                    {d.folders.length > 1 && (
                        <button style={{ ...btnStyle, background: "var(--button-danger-background, #da373c)" }}
                            onClick={async () => {
                                data.folders = data.folders.filter(f => f.name !== activeFolder.name);
                                data.pics = data.pics.filter(p => p.folder !== activeFolder.name);
                                setFolder(data.folders[0].name);
                                await persist();
                            }}>Delete folder</button>
                    )}
                </div>

                <div
                    onDragOver={e => e.preventDefault()}
                    onDrop={e => { e.preventDefault(); if (e.dataTransfer?.files?.length) onFiles(e.dataTransfer.files); }}
                    style={{ border: "2px dashed var(--background-modifier-accent)", borderRadius: 8, padding: 12, minHeight: 120 }}
                >
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(96px, 1fr))", gap: 8 }}>
                        <div style={addTileStyle} title="Add a picture" onClick={() => fileInput.current?.click()}>＋</div>
                        {pics.map(p => (
                            <div key={p.id} style={{ position: "relative" }}>
                                <img
                                    src={p.data}
                                    title={`${p.name} — click to attach`}
                                    style={{ width: "100%", height: 96, objectFit: "cover", borderRadius: 6, cursor: "pointer" }}
                                    onClick={() => { sendPic(p, targetChannelId); modalProps.onClose(); }}
                                />
                                <div style={{ position: "absolute", top: 2, right: 2, display: "flex", gap: 4 }}>
                                    <button
                                        style={overlayBtn}
                                        title={p.link ? "Send as link (cached — instant)" : "Send as link (uploads once to your link path)"}
                                        onClick={() => { sendAsLink(p, targetChannelId); modalProps.onClose(); }}
                                    >🔗</button>
                                    <button style={overlayBtn} title="Delete" onClick={async () => {
                                        data.pics = data.pics.filter(x => x.id !== p.id);
                                        await persist();
                                    }}>×</button>
                                </div>
                                {p.link && (
                                    <span title="Link cached" style={{
                                        position: "absolute", bottom: 4, right: 4, width: 8, height: 8,
                                        borderRadius: "50%", background: "#3ba55d",
                                    }} />
                                )}
                            </div>
                        ))}
                    </div>
                    <input
                        ref={fileInput}
                        type="file"
                        accept="image/*"
                        multiple
                        style={{ display: "none" }}
                        onChange={e => { if (e.currentTarget.files) onFiles(e.currentTarget.files); e.currentTarget.value = ""; }}
                    />
                </div>

                <Forms.FormText style={{ marginTop: 8, opacity: 0.7 }}>
                    Click a picture to attach it • 🔗 sends it as a link (first time uploads to your link
                    path, then it's cached) • add with ＋, drag-drop, paste, or right-click any image in
                    Discord → “Add to Fast Pictures”. Set the link path by right-clicking a channel →
                    “Use for Fast Pictures links”.
                </Forms.FormText>
            </ModalContent>
            <ModalFooter>
                <Button color={Button.Colors.PRIMARY} onClick={modalProps.onClose}>Close</Button>
            </ModalFooter>
        </ModalRoot>
    );
}

const openGallery = (targetChannelId?: string) =>
    openModal(props => <Gallery modalProps={props} targetChannelId={targetChannelId} />);

// Renders in every chat bar (main chat, voice-channel chat, threads, DMs) and
// remembers which channel its chat bar belongs to, so pictures go to THAT chat.
const FastPicturesButton = (props: any) => {
    const channelId: string | undefined = props?.channel?.id;
    return (
        <ChatBarButton tooltip="Fast Pictures" onClick={() => openGallery(channelId)}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="4" width="18" height="16" rx="2" stroke="currentColor" strokeWidth="2" />
                <circle cx="8.5" cy="9.5" r="1.5" fill="currentColor" />
                <path d="m4 18 5-5 3 3 3.5-3.5L20 16" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
            </svg>
        </ChatBarButton>
    );
};

// ---- Context menus -------------------------------------------------------------

function getImageUrl(message: any): string | null {
    const att = message?.attachments?.find((a: any) =>
        a.content_type?.startsWith("image/") ||
        /\.(png|jpe?g|gif|webp)$/i.test(a.filename || a.url || ""));
    if (att) return att.url || att.proxy_url || null;

    const emb = message?.embeds?.find((e: any) => e.image || e.thumbnail);
    if (emb) return emb.image?.url || emb.image?.proxyURL || emb.thumbnail?.url || emb.thumbnail?.proxyURL || null;

    return null;
}

const messageContextPatch: NavContextMenuPatchCallback = (children, props: any) => {
    const url = getImageUrl(props?.message);
    if (!url) return;
    children.push(
        <Menu.MenuItem
            id="fp-add"
            label="Add to Fast Pictures"
            action={() => addPicFromUrl(url, "image", data.folders[0]?.name ?? "General")}
        />,
    );
};

const channelContextPatch: NavContextMenuPatchCallback = (children, props: any) => {
    const channel = props?.channel;
    if (!channel?.id) return;
    children.push(
        <Menu.MenuItem
            id="fp-relay"
            label="Use for Fast Pictures links"
            action={async () => {
                settings.store.relayChannel = channel.id;
                toast("Fast Pictures link path set", Toasts.Type.SUCCESS);
            }}
        />,
    );
};

export default definePlugin({
    name: "FastPictures",
    description:
        "Favorite GIFs, but for your own photos — colored folders, one-click attach, cached send-as-link, add via drag/drop, paste, or right-click.",
    authors: [Devs.Ven ?? { name: "you", id: 0n }],
    settings,
    contextMenus: {
        "message": messageContextPatch,
        "channel-context": channelContextPatch,
        "user-context": channelContextPatch,
        "gdm-context": channelContextPatch,
    },
    async start() {
        await loadData();
        addChatBarButton("FastPictures", FastPicturesButton);
    },
    stop() {
        removeChatBarButton("FastPictures");
    },
});
