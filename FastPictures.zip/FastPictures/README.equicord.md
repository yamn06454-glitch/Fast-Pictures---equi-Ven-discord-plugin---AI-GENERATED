# FastPictures — Equicord install guide

**Favorite GIFs, but for your own photos.** Save images into colored folders and drop
them into any chat in one click — including voice-channel chats, threads, and DMs.

## Features

- 📁 **Folders with colors** — organize pictures into folders, each with its own color.
- 🖼 **One-click attach** — click a saved picture and it's attached to the current
  chat's message box (press Enter to send).
- 🔗 **Send as link (cached)** — uploads the picture **once** to a relay channel you
  pick, grabs the CDN link, caches it on the picture, and sends the link. Every later
  link-send of that picture is instant (green dot = link cached).
- ➕ **Four ways to add pictures:**
  1. the ＋ tile in the gallery (file picker)
  2. drag-and-drop onto the gallery
  3. paste (Ctrl+V) while the gallery is open
  4. right-click any image in Discord → **Add to Fast Pictures**
- 🎙 **Works everywhere** — the photo button appears in every chat bar (main chats,
  voice-room chats, threads, DMs) and sends to *that* chat.

## Install

> ⚠️ The **Equilotl** quick-installer installs a *prebuilt* Equicord which **cannot
> load userplugins**. You need a one-time source build.

Prerequisites: [Node.js](https://nodejs.org), pnpm (`npm i -g pnpm`), [git](https://git-scm.com).

```bash
git clone https://github.com/Equicord/Equicord
cd Equicord
pnpm install
```

Copy the `FastPictures` folder into the userplugins directory so you have:

```
Equicord/src/userplugins/FastPictures/index.tsx
```

Then build and inject over your existing Discord install:

```bash
pnpm build
pnpm inject
```

Fully quit Discord (system tray → **Quit Discord**), reopen it, then enable
**FastPictures** in **Settings → Equicord → Plugins**.

## Usage

1. Click the **photo icon** in the chat bar to open the gallery.
2. Add pictures with ＋ / drag-drop / paste, or right-click an image in any chat →
   **Add to Fast Pictures**.
3. Click a picture → attached to the chat. 🔗 → sent as a link.
4. **Set the link path once:** right-click a channel/DM you control →
   **Use for Fast Pictures links**. First 🔗 per picture uploads there; afterwards
   it's instant from cache.
5. Create folders with the name box + color picker; the second color picker recolors
   the open folder.

## Updating after Discord/Equicord updates

```bash
cd Equicord
git pull
pnpm install
pnpm build
```

then fully restart Discord. Re-run `pnpm inject` only if the Equicord section
disappears from Discord settings (means a Discord update wiped the patch).

## Troubleshooting

- **Changes don't show up after rebuilding** — Discord wasn't fully closed; kill it
  from the system tray (or Task Manager) and reopen. Background Discord processes
  keep serving the old bundle.
- **"Couldn't attach"** — the plugin first uses Discord's uploader module and falls
  back to simulating a paste; if both fail, Discord changed internals — check the
  console (Ctrl+Shift+I) for `[FastPictures]` errors.
- **🔗 says no link path set** — right-click a channel → **Use for Fast Pictures links**.
